import Cocoa

var one = "What do you call a magic owl?"
var two = "Hoodini"

print(one + "\n")
print("\t" + two)
